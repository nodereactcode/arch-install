# #!/bin/bash

# : '
# Creating a new initramfs is usually not required, because mkinitcpio was run on installation of the kernel package with pacstrap.
# For LVM, system encryption or RAID, modify mkinitcpio.conf(5) and recreate the initramfs image:'


# echo -e "\nInstalling packages for networking\n"
# mkinitcpio -P
# echo
