#!/bin/bash

echo -e "\nInstalling packages for networking\n"
pacman -S --noconfirm --needed networkmanager wpa_supplicant wireless_tools netctlpacman -S networkmanager wpa_supplicant wireless_tools netctl
echo

echo -e "\nInstall dialog (required for wifi-menu\n"
pacman -S --noconfirm --needed dialog
echo

echo -e "\nEnable networkmanager\n"
systemctl enable NetworkManager
echo