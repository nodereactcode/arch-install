#!/bin/bash

echo -e "\nSet time-zone\n"
#It sets timezone as Kathmandu
#Change if yours is different
ln -sf /usr/share/zoneinfo/Asia/Kathmandu /etc/localtime
echo

echo -e "\nRun hwclock to generate /etc/adjtime: \n"
hwclock --systohc
echo

#his command assumes the hardware clock is set to UTC