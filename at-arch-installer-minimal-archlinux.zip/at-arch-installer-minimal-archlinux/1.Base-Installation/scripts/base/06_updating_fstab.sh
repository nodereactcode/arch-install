#!/bin/bash
#Generate an fstab file (use -U or -L to define by UUID or labels, respectively):
echo -e "\nGenerating fstab\n"
genfstab -U /mnt >> /mnt/etc/fstab
echo

#Check the resulting /mnt/etc/fstab file, and edit it in case of errors.
