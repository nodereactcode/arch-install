#!/bin/bash

#Note: It requires modification to prevent data loss

echo -e "\nFormatting boot partition\n"
#Replace /dev/sda1 with your boot partition
mkfs.fat -F 32 /dev/sda1
echo

echo -e "\nFormatting root partition\n"
#Replace /dev/sda2 with your root partition
mkfs.ext4 /dev/sda2
echo
