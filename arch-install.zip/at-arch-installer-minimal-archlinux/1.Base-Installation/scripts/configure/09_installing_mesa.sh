#!/bin/bash

echo -e "\nInstalling Mesa package which includes most of the modern drivers for newer hardwar\n"
pacman -S --noconfirm --needed mesa
echo