#!/bin/bash

echo -e "\nSet password for root user\n"
passwd
echo