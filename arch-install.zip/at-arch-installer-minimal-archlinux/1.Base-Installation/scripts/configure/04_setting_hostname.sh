#!/bin/bash

echo -e "\nCreate the hostname file:\n"
#sets the name of computer
#can replace "arch" with your own
echo >> /etc/hostname archlinux
echo