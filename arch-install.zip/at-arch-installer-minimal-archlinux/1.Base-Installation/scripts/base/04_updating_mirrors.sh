#!/bin/bash

echo -e "\nDownloading latest mirrors\n"

echo -e "\nMaking backup of existing mirrors\n"
sudo cp /etc/pacman.d/mirrorlist /etc/pacman.d/mirrorlist.bak
echo

#Use reflector package
echo -e "\nInstalling  reflector Package\n"
sudo pacman -S reflector --noconfirm --needed
echo -e "\nCopying new mirrors\n"
reflector --country China,India,Germany,France --age 12 --protocol https --sort rate --save /etc/pacman.d/mirrorlist

echo -e "\nUpdating pacakge repository\n"
sudo pacman -Sy
echo

echo -e "\nRemoving temporary file\n"
rm mirrorlist
echo
