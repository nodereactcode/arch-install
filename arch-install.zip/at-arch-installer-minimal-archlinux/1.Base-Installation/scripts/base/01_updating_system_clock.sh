#!/bin/bash

echo -e "\nUpdate the system clock\n"
timedatectl set-ntp true
echo