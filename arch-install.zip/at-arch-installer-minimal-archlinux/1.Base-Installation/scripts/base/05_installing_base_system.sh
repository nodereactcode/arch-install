#!/bin/bash

#Install essential packages

# -K  initialize an empty pacman keyring in the target (implies -G).

# base implies minimal package set to define a basic Arch Linux installation
#linux latest kernal
#linux-firmware for common hardware.
#base-devel contains useful utilities which are used frequently
#wget is required to download AALI scripts inside chroot
#bash-completion helps in auto-completing commands hence included

echo -e "\nInstalling System. Use the pacstrap script to install the base package, Linux kernel and firmware for common hardware:
\n"
pacstrap -K /mnt base base-devel wget bash-completion linux linux-firmware man-db man-pages networkmanager vim 
echo