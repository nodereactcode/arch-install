#!/bin/bash

echo -e "\nChange root into the new system:\n"
arch-chroot /mnt
echo