#  Arch Linux Minimal  Install (Shell Script)

If boot root  partitions do not exist in your disk, they need to be created before this script is executed. You can use tools like fdisk, gdisk, parted or pseudo-graphics tool like cfdisk to create or modify the partitions. It is optimized for my Intel PC with UEFI boot mode along with separate home partition but will work on other PCs with different specs once you go through the script thoroughly and make the required changes as per your specifications and requirements.

The best approach is to clone [this repo](https://github.com/amrittimalsina/at-arch-installer) and  changes as per the specifications and requirements. This way the changes will be persistent and will be optimized for your PC.

Assuming you have already prepared an installation media and currently booted into it, you can follow these steps:

# Step: 1

Connect to the internet iwctl.
update mirrors

After internet connection is successfully established, issue the following commands to download Automated Arch Linux Installer scripts:

	$ wget https://github.com/amrittimalsina/at-arch-installer/tarball/master

	$ tar -xvf master

Now the scripts will be available in the working directory along with this documentation in the live media. If you have made changes to your scripts as per your requirements, you are ready to automate the installation.

What do you get in your working directory after you download the repository and untar it?

	A. Base Installation

		1.base-installation.sh

		2.configure-system.sh


# Step 2: Base Installation
Inside this directory, there are two scripts for setting up a base installation of Arch system automatically.

Phase 1 - Installing base system
Execute the following command to install the base system.

	$ cd at-arch-installer/1.Base-Installation/

	$ ./1.base-installation.sh

Followings are the list of actions performed:

	1. Updating system clock

	2. Formatting  partition (modification required)

	3. Mounting root and boot partitions (modification required)

	4. Updating to latest mirrors

	5. Installing base system

	6. Generating fstab

	7. Changing root

Phase 2 - Configuring system inside chroot

Download the  scripts again as you did in Step 1 and extract it then enter the Base Installation folder. Now issue following commands:

	$ ./2.configure-system.sh

This results in:

	1. Setting time-zone

	2. Setting up locale

	3. Setting up Language

	4. Setting hostname

	5. Setting network

	6. Creating new initramfs

	6. Setting up a password for root user

	7. Enable microcode updates in addition

	8. Install mesa Packages

	9. Installing grub

	10. Exiting chroot

	11. Unmounting partitions

	12. Reboot
